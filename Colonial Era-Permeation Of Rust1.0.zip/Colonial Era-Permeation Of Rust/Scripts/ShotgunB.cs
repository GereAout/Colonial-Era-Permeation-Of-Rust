using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Events;

namespace cepor
{
    public class ShotgunBehaviour : MonoBehaviour
    {
        public bool is_shotgun = false;
        public bool oneper = false;
        public int toggled_per = 12;

        void Start()
        {
            var FB = gameObject.GetComponent<FirearmBehaviour>();
            var PB = gameObject.GetComponent<PhysicalBehaviour>();

            //buttons initialization
            //each button concept references a function in rightclickeffects as unityevent
            var enable = new ContextMenuButton(() => is_shotgun && oneper == false, "useSlug", "Uses Slug", "Make the gun use slug.", (UnityAction)(() => slug(FB)));
            enable.LabelWhenMultipleAreSelected = "Use Slug";
            var disable = new ContextMenuButton(() => is_shotgun && oneper, "useBuck", "Uses Buckshot", "Make the gun use buckshot.", (UnityAction)(() => buck(FB, toggled_per)));
            disable.LabelWhenMultipleAreSelected = "Use Buckshot";
            PB.ContextMenuOptions.Buttons.Add(enable);
            PB.ContextMenuOptions.Buttons.Add(disable);
        }
        public static void slug(FirearmBehaviour FIB)
        {
                FIB.BulletsPerShot = 1;
        }
        public static void buck(FirearmBehaviour FIB, int per)
        {
                FIB.BulletsPerShot = per;
        }
    }
}
// Originally uploaded by 'Pump3d'. Do not reupload without their explicit permission.
