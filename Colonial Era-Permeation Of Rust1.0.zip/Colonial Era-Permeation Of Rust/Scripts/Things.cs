using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Events;
using System.Collections;

namespace cepor
{
    public class cepor
    {

        public static void Main()
        {
            //Category
            CategoryBuilder.Create("<color=#A30E1C>Rifles</color>", "Staring into the muzzles, then <color=#3B0A0A><i>die</i></color> or <i>survive</i>.", ModAPI.LoadSprite("Icons/Rifles.png"));
            CategoryBuilder.Create("<color=#A30E1C>Rapiers</color>", "She's so beautiful.", ModAPI.LoadSprite("Icons/Rapiers.png"));
            CategoryBuilder.Create("<color=#A30E1C>British Army</color>", "God Bless the King.", ModAPI.LoadSprite("Icons/Soldiers.png"));
            CategoryBuilder.Create("<color=#3D6B9E>Continental Army</color>", "<color=#A30E1C>Th</color><color=#3D6B9E>eir</color>Symbiosis, <color=#FFFFFF>Th</color><color=#3B0A0A>eir</color> blood.", ModAPI.LoadSprite("Icons/Soldiers.png"));
            //British Army
            ModAPI.Register(
                new Modification()
                {
                    OriginalItem = ModAPI.FindSpawnable("Human"),
                    NameOverride = "<color=#A30E1C>3rd Regiment of Foot\"The Buffs\"</color> Private",
                    NameToOrderByOverride = "1",
                    DescriptionOverride = "The private of <color=#A30E1C>3rd Regiment of Foot\"The Buffs\"</color>, uses Dog Lock Musket.",
                    CategoryOverride = ModAPI.FindCategory("<color=#A30E1C>British Army</color>"),
                    ThumbnailOverride = ModAPI.LoadSprite("Icons/Buffs_Private.png"),
                    AfterSpawn = (Instance) =>
                    {
                        var skin = ModAPI.LoadTexture("British/buffs_private.png");
                        var flesh = ModAPI.LoadTexture("HumanFlesh.png");
                        var bone = ModAPI.LoadTexture("HumanSkeleton.png");
                        Instance.GetComponent<PersonBehaviour>().SetBodyTextures(skin, flesh, bone);

                        //cosmetics
                        var head = Instance.transform.Find("Head");
                        var childObject = new GameObject("Hat");
                        childObject.transform.SetParent(head);
                        childObject.transform.localPosition = new Vector3(0.025f, 0.15f);
                        childObject.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject.transform.localScale = new Vector3(1f, 1f);
                        var childSprite = childObject.AddComponent<SpriteRenderer>();
                        childSprite.sprite = ModAPI.LoadSprite("British/hat.png");
                        childSprite.sortingLayerName = "Top";

                        var sockf = Instance.transform.Find("FrontLeg").Find("LowerLegFront");
                        var childObject1 = new GameObject("socks");
                        childObject1.transform.SetParent(sockf);
                        childObject1.transform.localPosition = new Vector3(0, -0.075f);
                        childObject1.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject1.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite1 = childObject1.AddComponent<SpriteRenderer>();
                        childSprite1.sprite = ModAPI.LoadSprite("British/socks.png");
                        childSprite1.sortingLayerName = "Top";

                        var sockb = Instance.transform.Find("BackLeg").Find("LowerLeg");
                        var childObject2 = new GameObject("socks");
                        childObject2.transform.SetParent(sockb);
                        childObject2.transform.localPosition = new Vector3(0, -0.075f);
                        childObject2.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject2.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite2 = childObject2.AddComponent<SpriteRenderer>();
                        childSprite2.sprite = ModAPI.LoadSprite("British/socks.png");
                        childSprite2.sortingLayerName = "Default";

                        var shoef = Instance.transform.Find("FrontLeg").Find("FootFront");
                        var childObject3 = new GameObject("shoes");
                        childObject3.transform.SetParent(shoef);
                        childObject3.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject3.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject3.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite3 = childObject3.AddComponent<SpriteRenderer>();
                        childSprite3.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite3.sortingLayerName = "Top";

                        var shoeb = Instance.transform.Find("BackLeg").Find("Foot");
                        var childObject4 = new GameObject("shoes");
                        childObject4.transform.SetParent(shoeb);
                        childObject4.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject4.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject4.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite4 = childObject4.AddComponent<SpriteRenderer>();
                        childSprite4.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite4.sortingLayerName = "Default";

                        var tailcoat = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject5 = new GameObject("tailcoat");
                        childObject5.transform.SetParent(tailcoat);
                        childObject5.transform.localPosition = new Vector3(-0.056f, -0.05f);
                        childObject5.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject5.transform.localScale = new Vector3(1f, 1f);
                        var childSprite5 = childObject5.AddComponent<SpriteRenderer>();
                        childSprite5.sprite = ModAPI.LoadSprite("British/tailcoat.png");
                        childSprite5.sortingLayerName = "Foreground";

                        var bag = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject6 = new GameObject("bag");
                        childObject6.transform.SetParent(bag);
                        childObject6.transform.localPosition = new Vector3(-0.05f, 0);
                        childObject6.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject6.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite6 = childObject6.AddComponent<SpriteRenderer>();
                        childSprite6.sprite = ModAPI.LoadSprite("British/bag.png");
                        childSprite6.sortingLayerName = "Foreground";

                        var collar = Instance.transform.Find("Body").Find("UpperBody");
                        var childObject7 = new GameObject("collar");
                        childObject7.transform.SetParent(collar);
                        childObject7.transform.localPosition = new Vector3(0f, 0.03f);
                        childObject7.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject7.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite7 = childObject7.AddComponent<SpriteRenderer>();
                        childSprite7.sprite = ModAPI.LoadSprite("British/collar.png");
                        childSprite7.sortingLayerName = "Top";

                        var sleevef = Instance.transform.Find("FrontArm").Find("LowerArmFront");
                        var childObject8 = new GameObject("sleeves");
                        childObject8.transform.SetParent(sleevef);
                        childObject8.transform.localPosition = new Vector3(0f, 0f);
                        childObject8.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject8.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite8 = childObject8.AddComponent<SpriteRenderer>();
                        childSprite8.sprite = ModAPI.LoadSprite("British/sleeves.png");
                        childSprite8.sortingLayerName = "Top";

                        var sleeveb = Instance.transform.Find("BackArm").Find("LowerArm");
                        var childObject9 = new GameObject("sleeves");
                        childObject9.transform.SetParent(sleeveb);
                        childObject9.transform.localPosition = new Vector3(0f, 0f);
                        childObject9.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject9.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite9 = childObject9.AddComponent<SpriteRenderer>();
                        childSprite9.sprite = ModAPI.LoadSprite("British/sleeves.png");
                        childSprite9.sortingLayerName = "Default";
                    }
                }
            );
            ModAPI.Register(
                new Modification()
                {
                    OriginalItem = ModAPI.FindSpawnable("Human"),
                    NameOverride = "<color=#A30E1C>3rd Regiment of Foot\"The Buffs\"</color> Officer",
                    NameToOrderByOverride = "2",
                    DescriptionOverride = "The officer of <color=#A30E1C>3rd Regiment of Foot\"The Buffs\"</color>.",
                    CategoryOverride = ModAPI.FindCategory("<color=#A30E1C>British Army</color>"),
                    ThumbnailOverride = ModAPI.LoadSprite("Icons/Buffs_Officer.png"),
                    AfterSpawn = (Instance) =>
                    {
                        var skin = ModAPI.LoadTexture("British/buffs_officer.png");
                        var flesh = ModAPI.LoadTexture("HumanFlesh.png");
                        var bone = ModAPI.LoadTexture("HumanSkeleton.png");
                        Instance.GetComponent<PersonBehaviour>().SetBodyTextures(skin, flesh, bone);

                        //cosmetics
                        var head = Instance.transform.Find("Head");
                        var childObject = new GameObject("Hat");
                        childObject.transform.SetParent(head);
                        childObject.transform.localPosition = new Vector3(0.025f, 0.15f);
                        childObject.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject.transform.localScale = new Vector3(1f, 1f);
                        var childSprite = childObject.AddComponent<SpriteRenderer>();
                        childSprite.sprite = ModAPI.LoadSprite("British/hat.png");
                        childSprite.sortingLayerName = "Top";

                        var sockf = Instance.transform.Find("FrontLeg").Find("LowerLegFront");
                        var childObject1 = new GameObject("socks");
                        childObject1.transform.SetParent(sockf);
                        childObject1.transform.localPosition = new Vector3(0, -0.075f);
                        childObject1.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject1.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite1 = childObject1.AddComponent<SpriteRenderer>();
                        childSprite1.sprite = ModAPI.LoadSprite("British/socks.png");
                        childSprite1.sortingLayerName = "Top";

                        var sockb = Instance.transform.Find("BackLeg").Find("LowerLeg");
                        var childObject2 = new GameObject("socks");
                        childObject2.transform.SetParent(sockb);
                        childObject2.transform.localPosition = new Vector3(0, -0.075f);
                        childObject2.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject2.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite2 = childObject2.AddComponent<SpriteRenderer>();
                        childSprite2.sprite = ModAPI.LoadSprite("British/socks.png");
                        childSprite2.sortingLayerName = "Default";

                        var shoef = Instance.transform.Find("FrontLeg").Find("FootFront");
                        var childObject3 = new GameObject("shoes");
                        childObject3.transform.SetParent(shoef);
                        childObject3.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject3.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject3.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite3 = childObject3.AddComponent<SpriteRenderer>();
                        childSprite3.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite3.sortingLayerName = "Top";

                        var shoeb = Instance.transform.Find("BackLeg").Find("Foot");
                        var childObject4 = new GameObject("shoes");
                        childObject4.transform.SetParent(shoeb);
                        childObject4.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject4.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject4.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite4 = childObject4.AddComponent<SpriteRenderer>();
                        childSprite4.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite4.sortingLayerName = "Default";

                        var tailcoat = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject5 = new GameObject("tailcoat");
                        childObject5.transform.SetParent(tailcoat);
                        childObject5.transform.localPosition = new Vector3(-0.056f, -0.05f);
                        childObject5.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject5.transform.localScale = new Vector3(1f, 1f);
                        var childSprite5 = childObject5.AddComponent<SpriteRenderer>();
                        childSprite5.sprite = ModAPI.LoadSprite("British/tailcoat.png");
                        childSprite5.sortingLayerName = "Foreground";

                        var belt = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject6 = new GameObject("belt");
                        childObject6.transform.SetParent(belt);
                        childObject6.transform.localPosition = new Vector3(-0.05f, 0);
                        childObject6.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject6.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite6 = childObject6.AddComponent<SpriteRenderer>();
                        childSprite6.sprite = ModAPI.LoadSprite("British/officer_belt.png");
                        childSprite6.sortingLayerName = "Foreground";

                        var collar = Instance.transform.Find("Body").Find("UpperBody");
                        var childObject7 = new GameObject("collar");
                        childObject7.transform.SetParent(collar);
                        childObject7.transform.localPosition = new Vector3(0f, -0.05f);
                        childObject7.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject7.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite7 = childObject7.AddComponent<SpriteRenderer>();
                        childSprite7.sprite = ModAPI.LoadSprite("British/officer_collar.png");
                        childSprite7.sortingLayerName = "Top";

                        var sleevef = Instance.transform.Find("FrontArm").Find("LowerArmFront");
                        var childObject8 = new GameObject("sleeves");
                        childObject8.transform.SetParent(sleevef);
                        childObject8.transform.localPosition = new Vector3(0f, 0f);
                        childObject8.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject8.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite8 = childObject8.AddComponent<SpriteRenderer>();
                        childSprite8.sprite = ModAPI.LoadSprite("British/sleeves.png");
                        childSprite8.sortingLayerName = "Top";

                        var sleeveb = Instance.transform.Find("BackArm").Find("LowerArm");
                        var childObject9 = new GameObject("sleeves");
                        childObject9.transform.SetParent(sleeveb);
                        childObject9.transform.localPosition = new Vector3(0f, 0f);
                        childObject9.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject9.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite9 = childObject9.AddComponent<SpriteRenderer>();
                        childSprite9.sprite = ModAPI.LoadSprite("British/sleeves.png");
                        childSprite9.sortingLayerName = "Default";
                    }
                }
            );
            ModAPI.Register(
                new Modification()
                {
                    OriginalItem = ModAPI.FindSpawnable("Human"),
                    NameOverride = "<color=#A30E1C>33rd Regiment of Foot</color> Grenadier",
                    NameToOrderByOverride = "3",
                    DescriptionOverride = "The grenadier of <color=#A30E1C>33rd Regiment of Foot</color>, uses Brown Bess. They are <i>\"Grenadiers\"</i>, but they hardly use grenades.",
                    CategoryOverride = ModAPI.FindCategory("<color=#A30E1C>British Army</color>"),
                    ThumbnailOverride = ModAPI.LoadSprite("Icons/grenadier.png"),
                    AfterSpawn = (Instance) =>
                    {
                        var skin = ModAPI.LoadTexture("British/grenadier.png");
                        var flesh = ModAPI.LoadTexture("HumanFlesh.png");
                        var bone = ModAPI.LoadTexture("HumanSkeleton.png");
                        Instance.GetComponent<PersonBehaviour>().SetBodyTextures(skin, flesh, bone);

                        //cosmetics
                        var head = Instance.transform.Find("Head");
                        var childObject = new GameObject("Hat");
                        childObject.transform.SetParent(head);
                        childObject.transform.localPosition = new Vector3(0, 0.19f);
                        childObject.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite = childObject.AddComponent<SpriteRenderer>();
                        childSprite.sprite = ModAPI.LoadSprite("British/grenadiercap.png");
                        childSprite.sortingLayerName = "Top";

                        var sockf = Instance.transform.Find("FrontLeg").Find("LowerLegFront");
                        var childObject1 = new GameObject("socks");
                        childObject1.transform.SetParent(sockf);
                        childObject1.transform.localPosition = new Vector3(-0.0250f, -0.075f);
                        childObject1.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject1.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite1 = childObject1.AddComponent<SpriteRenderer>();
                        childSprite1.sprite = ModAPI.LoadSprite("British/socks_grenadier.png");
                        childSprite1.sortingLayerName = "Top";

                        var sockb = Instance.transform.Find("BackLeg").Find("LowerLeg");
                        var childObject2 = new GameObject("socks");
                        childObject2.transform.SetParent(sockb);
                        childObject2.transform.localPosition = new Vector3(-0.0250f, -0.075f);
                        childObject2.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject2.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite2 = childObject2.AddComponent<SpriteRenderer>();
                        childSprite2.sprite = ModAPI.LoadSprite("British/socks_grenadier.png");
                        childSprite2.sortingLayerName = "Default";

                        var shoef = Instance.transform.Find("FrontLeg").Find("FootFront");
                        var childObject3 = new GameObject("shoes");
                        childObject3.transform.SetParent(shoef);
                        childObject3.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject3.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject3.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite3 = childObject3.AddComponent<SpriteRenderer>();
                        childSprite3.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite3.sortingLayerName = "Top";

                        var shoeb = Instance.transform.Find("BackLeg").Find("Foot");
                        var childObject4 = new GameObject("shoes");
                        childObject4.transform.SetParent(shoeb);
                        childObject4.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject4.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject4.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite4 = childObject4.AddComponent<SpriteRenderer>();
                        childSprite4.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite4.sortingLayerName = "Default";

                        var tailcoat = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject5 = new GameObject("tailcoat");
                        childObject5.transform.SetParent(tailcoat);
                        childObject5.transform.localPosition = new Vector3(-0.056f, -0.05f);
                        childObject5.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject5.transform.localScale = new Vector3(1f, 1f);
                        var childSprite5 = childObject5.AddComponent<SpriteRenderer>();
                        childSprite5.sprite = ModAPI.LoadSprite("British/tailcoat.png");
                        childSprite5.sortingLayerName = "Foreground";

                        var bag = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject6 = new GameObject("bag");
                        childObject6.transform.SetParent(bag);
                        childObject6.transform.localPosition = new Vector3(-0.05f, 0);
                        childObject6.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject6.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite6 = childObject6.AddComponent<SpriteRenderer>();
                        childSprite6.sprite = ModAPI.LoadSprite("British/grenadierbag.png");
                        childSprite6.sortingLayerName = "Foreground";

                        var sleevef = Instance.transform.Find("FrontArm").Find("LowerArmFront");
                        var childObject8 = new GameObject("sleeves");
                        childObject8.transform.SetParent(sleevef);
                        childObject8.transform.localPosition = new Vector3(0f, 0f);
                        childObject8.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject8.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite8 = childObject8.AddComponent<SpriteRenderer>();
                        childSprite8.sprite = ModAPI.LoadSprite("British/sleeves.png");
                        childSprite8.sortingLayerName = "Top";

                        var sleeveb = Instance.transform.Find("BackArm").Find("LowerArm");
                        var childObject9 = new GameObject("sleeves");
                        childObject9.transform.SetParent(sleeveb);
                        childObject9.transform.localPosition = new Vector3(0f, 0f);
                        childObject9.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject9.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite9 = childObject9.AddComponent<SpriteRenderer>();
                        childSprite9.sprite = ModAPI.LoadSprite("British/sleeves.png");
                        childSprite9.sortingLayerName = "Default";
                    }
                }
            );
            ModAPI.Register(
                new Modification()
                {
                    OriginalItem = ModAPI.FindSpawnable("Human"),
                    NameOverride = "<color=#A30E1C>East India Company</color> Sepoy",
                    NameToOrderByOverride = "4",
                    DescriptionOverride = "The private of <color=#A30E1C>East India Company</color>, most of them are Indian",
                    CategoryOverride = ModAPI.FindCategory("<color=#A30E1C>British Army</color>"),
                    ThumbnailOverride = ModAPI.LoadSprite("Icons/sepoy.png"),
                    AfterSpawn = (Instance) =>
                    {
                        var skin = ModAPI.LoadTexture("British/sepoy.png");
                        var flesh = ModAPI.LoadTexture("HumanFlesh.png");
                        var bone = ModAPI.LoadTexture("HumanSkeleton.png");
                        Instance.GetComponent<PersonBehaviour>().SetBodyTextures(skin, flesh, bone);

                        //cosmetics
                       var head = Instance.transform.Find("Head");
                        var childObject = new GameObject("Hat");
                        childObject.transform.SetParent(head);
                        childObject.transform.localPosition = new Vector3(0f, 0.15f);
                        childObject.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject.transform.localScale = new Vector3(1f, 1f);
                        var childSprite = childObject.AddComponent<SpriteRenderer>();
                        childSprite.sprite = ModAPI.LoadSprite("British/sepoy_hat.png");
                        childSprite.sortingLayerName = "Top";

                        var tailcoat = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject5 = new GameObject("tailcoat");
                        childObject5.transform.SetParent(tailcoat);
                        childObject5.transform.localPosition = new Vector3(-0.056f, -0.05f);
                        childObject5.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject5.transform.localScale = new Vector3(1f, 1f);
                        var childSprite5 = childObject5.AddComponent<SpriteRenderer>();
                        childSprite5.sprite = ModAPI.LoadSprite("British/tailcoat.png");
                        childSprite5.sortingLayerName = "Foreground";

                        var sleevef = Instance.transform.Find("FrontArm").Find("LowerArmFront");
                        var childObject8 = new GameObject("sleeves");
                        childObject8.transform.SetParent(sleevef);
                        childObject8.transform.localPosition = new Vector3(0f, 0f);
                        childObject8.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject8.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite8 = childObject8.AddComponent<SpriteRenderer>();
                        childSprite8.sprite = ModAPI.LoadSprite("British/sleeves_sepoy.png");
                        childSprite8.sortingLayerName = "Top";

                        var sleeveb = Instance.transform.Find("BackArm").Find("LowerArm");
                        var childObject9 = new GameObject("sleeves");
                        childObject9.transform.SetParent(sleeveb);
                        childObject9.transform.localPosition = new Vector3(0f, 0f);
                        childObject9.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject9.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite9 = childObject9.AddComponent<SpriteRenderer>();
                        childSprite9.sprite = ModAPI.LoadSprite("British/sleeves_sepoy.png");
                        childSprite9.sortingLayerName = "Default";
                    }
                    }
            );
            ModAPI.Register(
                new Modification()
                {
                    OriginalItem = ModAPI.FindSpawnable("Human"),
                    NameOverride = "<color=#A30E1C>5th Regiment of Foot</color> Private",
                    NameToOrderByOverride = "5",
                    DescriptionOverride = "The private of <color=#A30E1C>5th Regiment of Foot</color>, uses Brown Bess.",
                    CategoryOverride = ModAPI.FindCategory("<color=#A30E1C>British Army</color>"),
                    ThumbnailOverride = ModAPI.LoadSprite("Icons/5th_private.png"),
                    AfterSpawn = (Instance) =>
                    {
                        var skin = ModAPI.LoadTexture("British/5th_private.png");
                        var flesh = ModAPI.LoadTexture("HumanFlesh.png");
                        var bone = ModAPI.LoadTexture("HumanSkeleton.png");
                        Instance.GetComponent<PersonBehaviour>().SetBodyTextures(skin, flesh, bone);

                        //cosmetics
                        var head = Instance.transform.Find("Head");
                        var childObject = new GameObject("Hat");
                        childObject.transform.SetParent(head);
                        childObject.transform.localPosition = new Vector3(0.025f, 0.15f);
                        childObject.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject.transform.localScale = new Vector3(1f, 1f);
                        var childSprite = childObject.AddComponent<SpriteRenderer>();
                        childSprite.sprite = ModAPI.LoadSprite("British/hat.png");
                        childSprite.sortingLayerName = "Top";

                        var sockf = Instance.transform.Find("FrontLeg").Find("LowerLegFront");
                        var childObject1 = new GameObject("socks");
                        childObject1.transform.SetParent(sockf);
                        childObject1.transform.localPosition = new Vector3(0, -0.075f);
                        childObject1.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject1.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite1 = childObject1.AddComponent<SpriteRenderer>();
                        childSprite1.sprite = ModAPI.LoadSprite("British/socks.png");
                        childSprite1.sortingLayerName = "Top";

                        var sockb = Instance.transform.Find("BackLeg").Find("LowerLeg");
                        var childObject2 = new GameObject("socks");
                        childObject2.transform.SetParent(sockb);
                        childObject2.transform.localPosition = new Vector3(0, -0.075f);
                        childObject2.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject2.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite2 = childObject2.AddComponent<SpriteRenderer>();
                        childSprite2.sprite = ModAPI.LoadSprite("British/socks.png");
                        childSprite2.sortingLayerName = "Default";

                        var shoef = Instance.transform.Find("FrontLeg").Find("FootFront");
                        var childObject3 = new GameObject("shoes");
                        childObject3.transform.SetParent(shoef);
                        childObject3.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject3.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject3.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite3 = childObject3.AddComponent<SpriteRenderer>();
                        childSprite3.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite3.sortingLayerName = "Top";

                        var shoeb = Instance.transform.Find("BackLeg").Find("Foot");
                        var childObject4 = new GameObject("shoes");
                        childObject4.transform.SetParent(shoeb);
                        childObject4.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject4.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject4.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite4 = childObject4.AddComponent<SpriteRenderer>();
                        childSprite4.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite4.sortingLayerName = "Default";

                        var tailcoat = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject5 = new GameObject("tailcoat");
                        childObject5.transform.SetParent(tailcoat);
                        childObject5.transform.localPosition = new Vector3(-0.056f, -0.05f);
                        childObject5.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject5.transform.localScale = new Vector3(1f, 1f);
                        var childSprite5 = childObject5.AddComponent<SpriteRenderer>();
                        childSprite5.sprite = ModAPI.LoadSprite("British/tailcoat.png");
                        childSprite5.sortingLayerName = "Foreground";

                        var bag = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject6 = new GameObject("bag");
                        childObject6.transform.SetParent(bag);
                        childObject6.transform.localPosition = new Vector3(-0.05f, 0);
                        childObject6.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject6.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite6 = childObject6.AddComponent<SpriteRenderer>();
                        childSprite6.sprite = ModAPI.LoadSprite("British/bag.png");
                        childSprite6.sortingLayerName = "Foreground";

                        var sleevef = Instance.transform.Find("FrontArm").Find("LowerArmFront");
                        var childObject8 = new GameObject("sleeves");
                        childObject8.transform.SetParent(sleevef);
                        childObject8.transform.localPosition = new Vector3(0f, 0f);
                        childObject8.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject8.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite8 = childObject8.AddComponent<SpriteRenderer>();
                        childSprite8.sprite = ModAPI.LoadSprite("British/sleeves_5th.png");
                        childSprite8.sortingLayerName = "Top";

                        var sleeveb = Instance.transform.Find("BackArm").Find("LowerArm");
                        var childObject9 = new GameObject("sleeves");
                        childObject9.transform.SetParent(sleeveb);
                        childObject9.transform.localPosition = new Vector3(0f, 0f);
                        childObject9.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject9.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite9 = childObject9.AddComponent<SpriteRenderer>();
                        childSprite9.sprite = ModAPI.LoadSprite("British/sleeves_5th.png");
                        childSprite9.sortingLayerName = "Default";
                    }
                }
            );
            ModAPI.Register(
                new Modification()
                {
                    OriginalItem = ModAPI.FindSpawnable("Human"),
                    NameOverride = "<color=#A30E1C>5th Regiment of Foot</color> Grenadier",
                    NameToOrderByOverride = "6",
                    DescriptionOverride = "The grenadier of <color=#A30E1C>5th Regiment of Foot</color>, uses Brown Bess. They are <i>\"Grenadiers\"</i>, but they hardly use grenades.",
                    CategoryOverride = ModAPI.FindCategory("<color=#A30E1C>British Army</color>"),
                    ThumbnailOverride = ModAPI.LoadSprite("Icons/5th_grenadier.png"),
                    AfterSpawn = (Instance) =>
                    {
                        var skin = ModAPI.LoadTexture("British/grenadier_5th.png");
                        var flesh = ModAPI.LoadTexture("HumanFlesh.png");
                        var bone = ModAPI.LoadTexture("HumanSkeleton.png");
                        Instance.GetComponent<PersonBehaviour>().SetBodyTextures(skin, flesh, bone);

                        //cosmetics
                        var head = Instance.transform.Find("Head");
                        var childObject = new GameObject("Hat");
                        childObject.transform.SetParent(head);
                        childObject.transform.localPosition = new Vector3(0, 0.19f);
                        childObject.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite = childObject.AddComponent<SpriteRenderer>();
                        childSprite.sprite = ModAPI.LoadSprite("British/grenadiercap_5th.png");
                        childSprite.sortingLayerName = "Top";

                        var sockf = Instance.transform.Find("FrontLeg").Find("LowerLegFront");
                        var childObject1 = new GameObject("socks");
                        childObject1.transform.SetParent(sockf);
                        childObject1.transform.localPosition = new Vector3(-0.0250f, -0.075f);
                        childObject1.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject1.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite1 = childObject1.AddComponent<SpriteRenderer>();
                        childSprite1.sprite = ModAPI.LoadSprite("British/socks_grenadier.png");
                        childSprite1.sortingLayerName = "Top";

                        var sockb = Instance.transform.Find("BackLeg").Find("LowerLeg");
                        var childObject2 = new GameObject("socks");
                        childObject2.transform.SetParent(sockb);
                        childObject2.transform.localPosition = new Vector3(-0.0250f, -0.075f);
                        childObject2.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject2.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite2 = childObject2.AddComponent<SpriteRenderer>();
                        childSprite2.sprite = ModAPI.LoadSprite("British/socks_grenadier.png");
                        childSprite2.sortingLayerName = "Default";

                        var shoef = Instance.transform.Find("FrontLeg").Find("FootFront");
                        var childObject3 = new GameObject("shoes");
                        childObject3.transform.SetParent(shoef);
                        childObject3.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject3.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject3.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite3 = childObject3.AddComponent<SpriteRenderer>();
                        childSprite3.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite3.sortingLayerName = "Top";

                        var shoeb = Instance.transform.Find("BackLeg").Find("Foot");
                        var childObject4 = new GameObject("shoes");
                        childObject4.transform.SetParent(shoeb);
                        childObject4.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject4.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject4.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite4 = childObject4.AddComponent<SpriteRenderer>();
                        childSprite4.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite4.sortingLayerName = "Default";

                        var tailcoat = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject5 = new GameObject("tailcoat");
                        childObject5.transform.SetParent(tailcoat);
                        childObject5.transform.localPosition = new Vector3(-0.056f, -0.05f);
                        childObject5.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject5.transform.localScale = new Vector3(1f, 1f);
                        var childSprite5 = childObject5.AddComponent<SpriteRenderer>();
                        childSprite5.sprite = ModAPI.LoadSprite("British/tailcoat.png");
                        childSprite5.sortingLayerName = "Foreground";

                        var bag = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject6 = new GameObject("bag");
                        childObject6.transform.SetParent(bag);
                        childObject6.transform.localPosition = new Vector3(-0.05f, 0);
                        childObject6.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject6.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite6 = childObject6.AddComponent<SpriteRenderer>();
                        childSprite6.sprite = ModAPI.LoadSprite("British/grenadierbag.png");
                        childSprite6.sortingLayerName = "Foreground";

                        var sleevef = Instance.transform.Find("FrontArm").Find("LowerArmFront");
                        var childObject8 = new GameObject("sleeves");
                        childObject8.transform.SetParent(sleevef);
                        childObject8.transform.localPosition = new Vector3(0f, 0f);
                        childObject8.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject8.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite8 = childObject8.AddComponent<SpriteRenderer>();
                        childSprite8.sprite = ModAPI.LoadSprite("British/sleeves.png");
                        childSprite8.sortingLayerName = "Top";

                        var sleeveb = Instance.transform.Find("BackArm").Find("LowerArm");
                        var childObject9 = new GameObject("sleeves");
                        childObject9.transform.SetParent(sleeveb);
                        childObject9.transform.localPosition = new Vector3(0f, 0f);
                        childObject9.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject9.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite9 = childObject9.AddComponent<SpriteRenderer>();
                        childSprite9.sprite = ModAPI.LoadSprite("British/sleeves.png");
                        childSprite9.sortingLayerName = "Default";
                    }
                }
            );
            ModAPI.Register(
                new Modification()
                {
                    OriginalItem = ModAPI.FindSpawnable("Human"),
                    NameOverride = "<color=#A30E1C>96th Rifles</color> Rifleman",
                    NameToOrderByOverride = "7",
                    DescriptionOverride = "The rifleman of <color=#A30E1C>95th Rifles</color>, uses Backer Rifle, very first snipers.",
                    CategoryOverride = ModAPI.FindCategory("<color=#A30E1C>British Army</color>"),
                    ThumbnailOverride = ModAPI.LoadSprite("Icons/95th.png"),
                    AfterSpawn = (Instance) =>
                    {
                        var skin = ModAPI.LoadTexture("British/95th.png");
                        var flesh = ModAPI.LoadTexture("HumanFlesh.png");
                        var bone = ModAPI.LoadTexture("HumanSkeleton.png");
                        Instance.GetComponent<PersonBehaviour>().SetBodyTextures(skin, flesh, bone);

                        //cosmetics
                        var head = Instance.transform.Find("Head");
                        var childObject = new GameObject("Hat");
                        childObject.transform.SetParent(head);
                        childObject.transform.localPosition = new Vector3(0, 0.19f);
                        childObject.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite = childObject.AddComponent<SpriteRenderer>();
                        childSprite.sprite = ModAPI.LoadSprite("British/95th_cap.png");
                        childSprite.sortingLayerName = "Top";

                        var shoef = Instance.transform.Find("FrontLeg").Find("FootFront");
                        var childObject3 = new GameObject("shoes");
                        childObject3.transform.SetParent(shoef);
                        childObject3.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject3.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject3.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite3 = childObject3.AddComponent<SpriteRenderer>();
                        childSprite3.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite3.sortingLayerName = "Top";

                        var shoeb = Instance.transform.Find("BackLeg").Find("Foot");
                        var childObject4 = new GameObject("shoes");
                        childObject4.transform.SetParent(shoeb);
                        childObject4.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject4.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject4.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite4 = childObject4.AddComponent<SpriteRenderer>();
                        childSprite4.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite4.sortingLayerName = "Default";

                        var sleevef = Instance.transform.Find("FrontArm").Find("LowerArmFront");
                        var childObject8 = new GameObject("sleeves");
                        childObject8.transform.SetParent(sleevef);
                        childObject8.transform.localPosition = new Vector3(0f, 0f);
                        childObject8.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject8.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite8 = childObject8.AddComponent<SpriteRenderer>();
                        childSprite8.sprite = ModAPI.LoadSprite("British/sleeves_95th.png");
                        childSprite8.sortingLayerName = "Top";

                        var sleeveb = Instance.transform.Find("BackArm").Find("LowerArm");
                        var childObject9 = new GameObject("sleeves");
                        childObject9.transform.SetParent(sleeveb);
                        childObject9.transform.localPosition = new Vector3(0f, 0f);
                        childObject9.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject9.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite9 = childObject9.AddComponent<SpriteRenderer>();
                        childSprite9.sprite = ModAPI.LoadSprite("British/sleeves_95th.png");
                        childSprite9.sortingLayerName = "Default";
                    }
                }
            );
            ModAPI.Register(
                new Modification()
                {
                    OriginalItem = ModAPI.FindSpawnable("Human"),
                    NameOverride = "<color=#A30E1C>24th Regiment of Foot</color> Private",
                    NameToOrderByOverride = "8",
                    DescriptionOverride = "The private of <color=#A30E1C>24th Regiment of Foot</color>, uses Martini Henry.",
                    CategoryOverride = ModAPI.FindCategory("<color=#A30E1C>British Army</color>"),
                    ThumbnailOverride = ModAPI.LoadSprite("Icons/24th.png"),
                    AfterSpawn = (Instance) =>
                    {
                        var skin = ModAPI.LoadTexture("British/24th_private.png");
                        var flesh = ModAPI.LoadTexture("HumanFlesh.png");
                        var bone = ModAPI.LoadTexture("HumanSkeleton.png");
                        Instance.GetComponent<PersonBehaviour>().SetBodyTextures(skin, flesh, bone);

                        //cosmetics
                        var head = Instance.transform.Find("Head");
                        var childObject = new GameObject("Hat");
                        childObject.transform.SetParent(head);
                        childObject.transform.localPosition = new Vector3(0, 0.19f);
                        childObject.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite = childObject.AddComponent<SpriteRenderer>();
                        childSprite.sprite = ModAPI.LoadSprite("British/24th_cap.png");
                        childSprite.sortingLayerName = "Top";

                        var shoef = Instance.transform.Find("FrontLeg").Find("FootFront");
                        var childObject3 = new GameObject("shoes");
                        childObject3.transform.SetParent(shoef);
                        childObject3.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject3.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject3.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite3 = childObject3.AddComponent<SpriteRenderer>();
                        childSprite3.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite3.sortingLayerName = "Top";

                        var shoeb = Instance.transform.Find("BackLeg").Find("Foot");
                        var childObject4 = new GameObject("shoes");
                        childObject4.transform.SetParent(shoeb);
                        childObject4.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject4.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject4.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite4 = childObject4.AddComponent<SpriteRenderer>();
                        childSprite4.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite4.sortingLayerName = "Default";

                        var tailcoat = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject5 = new GameObject("tailcoat");
                        childObject5.transform.SetParent(tailcoat);
                        childObject5.transform.localPosition = new Vector3(-0.056f, -0.05f);
                        childObject5.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject5.transform.localScale = new Vector3(1f, 1f);
                        var childSprite5 = childObject5.AddComponent<SpriteRenderer>();
                        childSprite5.sprite = ModAPI.LoadSprite("British/tailcoat.png");
                        childSprite5.sortingLayerName = "Foreground";

                        var bag = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject6 = new GameObject("bag");
                        childObject6.transform.SetParent(bag);
                        childObject6.transform.localPosition = new Vector3(-0.05f, 0);
                        childObject6.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject6.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite6 = childObject6.AddComponent<SpriteRenderer>();
                        childSprite6.sprite = ModAPI.LoadSprite("British/bag.png");
                        childSprite6.sortingLayerName = "Foreground";

                        var sleevef = Instance.transform.Find("FrontArm").Find("LowerArmFront");
                        var childObject8 = new GameObject("sleeves");
                        childObject8.transform.SetParent(sleevef);
                        childObject8.transform.localPosition = new Vector3(0f, 0f);
                        childObject8.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject8.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite8 = childObject8.AddComponent<SpriteRenderer>();
                        childSprite8.sprite = ModAPI.LoadSprite("British/sleeves_24th.png");
                        childSprite8.sortingLayerName = "Top";

                        var sleeveb = Instance.transform.Find("BackArm").Find("LowerArm");
                        var childObject9 = new GameObject("sleeves");
                        childObject9.transform.SetParent(sleeveb);
                        childObject9.transform.localPosition = new Vector3(0f, 0f);
                        childObject9.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject9.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite9 = childObject9.AddComponent<SpriteRenderer>();
                        childSprite9.sprite = ModAPI.LoadSprite("British/sleeves_24th.png");
                        childSprite9.sortingLayerName = "Default";
                    }
                }
            );
            ModAPI.Register(
                new Modification()
                {
                    OriginalItem = ModAPI.FindSpawnable("Human"),
                    NameOverride = "<color=#A30E1C>42nd Regiment of Foot \"Black Watch\"</color> Private",
                    NameToOrderByOverride = "9",
                    DescriptionOverride = "The private of <color=#A30E1C>42nd Regiment of Foot \"Black Watch\"</color>, uses Brown Bess, wears Kilt",
                    CategoryOverride = ModAPI.FindCategory("<color=#A30E1C>British Army</color>"),
                    ThumbnailOverride = ModAPI.LoadSprite("Icons/bw.png"),
                    AfterSpawn = (Instance) =>
                    {
                        var skin = ModAPI.LoadTexture("British/bw_private.png");
                        var flesh = ModAPI.LoadTexture("HumanFlesh.png");
                        var bone = ModAPI.LoadTexture("HumanSkeleton.png");
                        Instance.GetComponent<PersonBehaviour>().SetBodyTextures(skin, flesh, bone);

                        //cosmetics
                        var head = Instance.transform.Find("Head");
                        var childObject = new GameObject("Hat");
                        childObject.transform.SetParent(head);
                        childObject.transform.localPosition = new Vector3(0, 0.19f);
                        childObject.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite = childObject.AddComponent<SpriteRenderer>();
                        childSprite.sprite = ModAPI.LoadSprite("British/bw_cap.png");
                        childSprite.sortingLayerName = "Top";

                        var sockf = Instance.transform.Find("FrontLeg").Find("LowerLegFront");
                        var childObject1 = new GameObject("socks");
                        childObject1.transform.SetParent(sockf);
                        childObject1.transform.localPosition = new Vector3(-0.0250f, -0.075f);
                        childObject1.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject1.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite1 = childObject1.AddComponent<SpriteRenderer>();
                        childSprite1.sprite = ModAPI.LoadSprite("British/socks_bw.png");
                        childSprite1.sortingLayerName = "Top";

                        var sockb = Instance.transform.Find("BackLeg").Find("LowerLeg");
                        var childObject2 = new GameObject("socks");
                        childObject2.transform.SetParent(sockb);
                        childObject2.transform.localPosition = new Vector3(-0.0250f, -0.075f);
                        childObject2.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject2.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite2 = childObject2.AddComponent<SpriteRenderer>();
                        childSprite2.sprite = ModAPI.LoadSprite("British/socks_bw.png");
                        childSprite2.sortingLayerName = "Default";

                        var shoef = Instance.transform.Find("FrontLeg").Find("FootFront");
                        var childObject3 = new GameObject("shoes");
                        childObject3.transform.SetParent(shoef);
                        childObject3.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject3.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject3.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite3 = childObject3.AddComponent<SpriteRenderer>();
                        childSprite3.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite3.sortingLayerName = "Top";

                        var shoeb = Instance.transform.Find("BackLeg").Find("Foot");
                        var childObject4 = new GameObject("shoes");
                        childObject4.transform.SetParent(shoeb);
                        childObject4.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject4.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject4.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite4 = childObject4.AddComponent<SpriteRenderer>();
                        childSprite4.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite4.sortingLayerName = "Default";

                        var tailcoat = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject5 = new GameObject("tailcoat");
                        childObject5.transform.SetParent(tailcoat);
                        childObject5.transform.localPosition = new Vector3(-0.056f, -0.05f);
                        childObject5.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject5.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite5 = childObject5.AddComponent<SpriteRenderer>();
                        childSprite5.sprite = ModAPI.LoadSprite("British/kilt.png");
                        childSprite5.sortingLayerName = "Foreground";

                        var bag = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject6 = new GameObject("bag");
                        childObject6.transform.SetParent(bag);
                        childObject6.transform.localPosition = new Vector3(-0.05f, 0);
                        childObject6.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject6.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite6 = childObject6.AddComponent<SpriteRenderer>();
                        childSprite6.sprite = ModAPI.LoadSprite("British/grenadierbag.png");
                        childSprite6.sortingLayerName = "Foreground";

                        var sleevef = Instance.transform.Find("FrontArm").Find("LowerArmFront");
                        var childObject8 = new GameObject("sleeves");
                        childObject8.transform.SetParent(sleevef);
                        childObject8.transform.localPosition = new Vector3(0f, 0f);
                        childObject8.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject8.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite8 = childObject8.AddComponent<SpriteRenderer>();
                        childSprite8.sprite = ModAPI.LoadSprite("British/sleeves_bw.png");
                        childSprite8.sortingLayerName = "Top";

                        var sleeveb = Instance.transform.Find("BackArm").Find("LowerArm");
                        var childObject9 = new GameObject("sleeves");
                        childObject9.transform.SetParent(sleeveb);
                        childObject9.transform.localPosition = new Vector3(0f, 0f);
                        childObject9.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject9.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite9 = childObject9.AddComponent<SpriteRenderer>();
                        childSprite9.sprite = ModAPI.LoadSprite("British/sleeves_bw.png");
                        childSprite9.sortingLayerName = "Default";
                    }
                }
            );
            ModAPI.Register(
            new Modification()
             {
                 OriginalItem = ModAPI.FindSpawnable("Flintlock Pistol"),
                 NameOverride = "Dog Lock Musket",
                 NameToOrderByOverride = "a",
                 DescriptionOverride = "The rifle mainly used by <color=#A30E1C>\"The Buffs\"</color> private.",
                 CategoryOverride = ModAPI.FindCategory("<color=#A30E1C>Rifles</color>"),
                 ThumbnailOverride = ModAPI.LoadSprite("Icons/doglockmusket.png"),
                 AfterSpawn = (Instance) =>
                 {
                   var Weapon = Instance.transform;
                   var Cover = new GameObject("Cover");
                   Cover.transform.SetParent(Weapon);
                   Cover.transform.localPosition = new Vector3(0f, 0f);
                   Cover.transform.localRotation = Weapon.localRotation;
                   Cover.transform.localScale = new Vector3(1f, 1f);
                   Instance.GetComponent<PhysicalBehaviour>().HoldingPositions = new Vector3[]
                     {
                           new Vector3(-0.5f, 0f),
                           new Vector3(0.3f,-0f),
                     };

                     ModAPI.KeepExtraObjects();

                     var Slide = Instance.transform.Find("Hammer");
                     Slide.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/doglockmusket_hammer.png");
                     Slide.transform.localPosition = new Vector3(-0.6f, 0.05f);
                     Slide.GetComponent<SpriteRenderer>().sortingOrder = 20;

                     var Spark = Instance.transform.Find("Sparks");
                     Spark.transform.localPosition = new Vector3(-0.57f,0f);

                     Instance.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/doglockmusket_col.png");
                     foreach (var c in Instance.GetComponents<Collider2D>())
                     {
                         GameObject.Destroy(c);
                     }
                     Instance.FixColliders();
                     Instance.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/doglockmusket.png");
                     var firearm = Instance.GetComponent<FirearmBehaviour>();
                     firearm.BulletsPerShot = 1;
                     firearm.FireDelay = 0.04f;
                     firearm.InitialInaccuracy = 0.015f;
                     firearm.EjectShells = false;
                     firearm.barrelPosition = new Vector2(0.57f, 0f);
                     firearm.ShotSounds = new AudioClip[]
                     {
                           ModAPI.LoadSound("Sounds/Musket.wav"),
                     };
                     Cartridge customCartridge = ModAPI.FindCartridge("9mm");
                     customCartridge.name = ".615";
                     customCartridge.Damage = 20f;
                     customCartridge.Recoil = 1.8f;
                     customCartridge.ImpactForce = 1.5f;
                     customCartridge.StartSpeed = 6f;
                     firearm.Cartridge = customCartridge;

                     Instance.AddComponent<UseEventTrigger>().Action = () =>
                     {
                        ModAPI.CreateParticleEffect("Flash", Instance.transform.position);
                     };
                     
                     var phys = Instance.GetComponent<PhysicalBehaviour>().Properties;
                     phys.Sharp = false;
                     Instance.GetComponent<PhysicalBehaviour>().TrueInitialMass = 0.35f;
                 }
             }
            );
            ModAPI.Register(
            new Modification()
             {
                 OriginalItem = ModAPI.FindSpawnable("Flintlock Pistol"),
                 NameOverride = "Brown Bess",
                 NameToOrderByOverride = "b",
                 DescriptionOverride = "The rifle mainly used by <color=#A30E1C>33rd Regiment of Foot</color>, <color=#A30E1C>5th Regiment of Foot</color> and <color=#A30E1C>42nd Regiment of Foot \"Black Watch\"</color>.",
                 CategoryOverride = ModAPI.FindCategory("<color=#A30E1C>Rifles</color>"),
                 ThumbnailOverride = ModAPI.LoadSprite("Icons/brownbess.png"),
                 AfterSpawn = (Instance) =>
                 {
                   var Weapon = Instance.transform;
                   var Cover = new GameObject("Cover");
                   Cover.transform.SetParent(Weapon);
                   Cover.transform.localPosition = new Vector3(0f, 0f);
                   Cover.transform.localRotation = Weapon.localRotation;
                   Cover.transform.localScale = new Vector3(1f, 1f);
                   Instance.GetComponent<PhysicalBehaviour>().HoldingPositions = new Vector3[]
                     {
                           new Vector3(-0.5f, 0f),
                           new Vector3(0.3f,-0f),
                     };

                     ModAPI.KeepExtraObjects();

                     var Slide = Instance.transform.Find("Hammer");
                     Slide.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/doglockmusket_hammer.png");
                     Slide.transform.localPosition = new Vector3(-0.6f, 0.05f);
                     Slide.GetComponent<SpriteRenderer>().sortingOrder = 20;

                     var Spark = Instance.transform.Find("Sparks");
                     Spark.transform.localPosition = new Vector3(-0.57f,0f);

                     Instance.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/Brown Bess_col.png");
                     foreach (var c in Instance.GetComponents<Collider2D>())
                     {
                         GameObject.Destroy(c);
                     }
                     Instance.FixColliders();
                     Instance.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/Brown Bess.png");
                     var firearm = Instance.GetComponent<FirearmBehaviour>();
                     firearm.BulletsPerShot = 1;
                     firearm.FireDelay = 0.04f;
                     firearm.InitialInaccuracy = 0.015f;
                     firearm.EjectShells = false;
                     firearm.barrelPosition = new Vector2(0.57f, 0f);
                     Cartridge customCartridge = ModAPI.FindCartridge("9mm");
                     customCartridge.name = ".75";
                     customCartridge.Damage = 20f;
                     customCartridge.Recoil = 1.8f;
                     customCartridge.ImpactForce = 1.5f;
                     customCartridge.StartSpeed = 6f;
                     firearm.Cartridge = customCartridge;
                     firearm.ShotSounds = new AudioClip[]
                     {
                           ModAPI.LoadSound("Sounds/Musket.wav"),
                     };
                     
                     var phys = Instance.GetComponent<PhysicalBehaviour>().Properties;
                     phys.Sharp = false;
                     Instance.GetComponent<PhysicalBehaviour>().TrueInitialMass = 0.35f;
                 }
             }
            );
            ModAPI.Register(
            new Modification()
             {
                 OriginalItem = ModAPI.FindSpawnable("Flintlock Pistol"),
                 NameOverride = "Baker Rifle",
                 NameToOrderByOverride = "c",
                 DescriptionOverride = "The rifle mainly used by <color=#A30E1C>95th Rifles</color>, a revolution of British rifles.",
                 CategoryOverride = ModAPI.FindCategory("<color=#A30E1C>Rifles</color>"),
                 ThumbnailOverride = ModAPI.LoadSprite("Icons/baker.png"),
                 AfterSpawn = (Instance) =>
                 {
                   var Weapon = Instance.transform;
                   var Cover = new GameObject("Cover");
                   Cover.transform.SetParent(Weapon);
                   Cover.transform.localPosition = new Vector3(0f, 0f);
                   Cover.transform.localRotation = Weapon.localRotation;
                   Cover.transform.localScale = new Vector3(1f, 1f);
                   Instance.GetComponent<PhysicalBehaviour>().HoldingPositions = new Vector3[]
                     {
                           new Vector3(-0.5f, 0f),
                           new Vector3(0.3f,-0f),
                     };

                     ModAPI.KeepExtraObjects();

                     var Slide = Instance.transform.Find("Hammer");
                     Slide.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/doglockmusket_hammer.png");
                     Slide.transform.localPosition = new Vector3(-0.6f, 0.05f);
                     Slide.GetComponent<SpriteRenderer>().sortingOrder = 20;

                     var Spark = Instance.transform.Find("Sparks");
                     Spark.transform.localPosition = new Vector3(-0.57f,0f);

                     Instance.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/Baker_col.png");
                     foreach (var c in Instance.GetComponents<Collider2D>())
                     {
                         GameObject.Destroy(c);
                     }
                     Instance.FixColliders();
                     Instance.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/Baker.png");
                     var firearm = Instance.GetComponent<FirearmBehaviour>();
                     firearm.BulletsPerShot = 1;
                     firearm.FireDelay = 0.04f;
                     firearm.InitialInaccuracy = 0.005f;
                     firearm.EjectShells = false;
                     firearm.barrelPosition = new Vector2(0.57f, 0f);
                     Cartridge customCartridge = ModAPI.FindCartridge("9mm");
                     customCartridge.name = ".625";
                     customCartridge.Damage = 20f;
                     customCartridge.Recoil = 1.8f;
                     customCartridge.ImpactForce = 1.5f;
                     customCartridge.StartSpeed = 10f;
                     firearm.Cartridge = customCartridge;
                     firearm.ShotSounds = new AudioClip[]
                     {
                           ModAPI.LoadSound("Sounds/Musket.wav"),
                     };
                     
                     var phys = Instance.GetComponent<PhysicalBehaviour>().Properties;
                     phys.Sharp = false;
                     Instance.GetComponent<PhysicalBehaviour>().TrueInitialMass = 0.35f;
                 }
             }
            );
            ModAPI.Register(
            new Modification()
             {
                 OriginalItem = ModAPI.FindSpawnable("Flintlock Pistol"),
                 NameOverride = "Pattern 1853 Enfield",
                 NameToOrderByOverride = "d",
                 DescriptionOverride = "The rifle mainly used by <color=#A30E1C>East India Company</color> Sepoy.",
                 CategoryOverride = ModAPI.FindCategory("<color=#A30E1C>Rifles</color>"),
                 ThumbnailOverride = ModAPI.LoadSprite("Icons/enfieldP53.png"),
                 AfterSpawn = (Instance) =>
                 {
                   var Weapon = Instance.transform;
                   var Cover = new GameObject("Cover");
                   Cover.transform.SetParent(Weapon);
                   Cover.transform.localPosition = new Vector3(0f, 0f);
                   Cover.transform.localRotation = Weapon.localRotation;
                   Cover.transform.localScale = new Vector3(1f, 1f);
                   Instance.GetComponent<PhysicalBehaviour>().HoldingPositions = new Vector3[]
                     {
                           new Vector3(-0.5f, 0f),
                           new Vector3(0.3f,-0f),
                     };

                     ModAPI.KeepExtraObjects();

                     var Slide = Instance.transform.Find("Hammer");
                     Slide.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/Enfield1853_hammer.png");
                     Slide.transform.localPosition = new Vector3(-0.6f, 0.05f);
                     Slide.GetComponent<SpriteRenderer>().sortingOrder = 20;

                     var Spark = Instance.transform.Find("Sparks");
                     Spark.transform.localPosition = new Vector3(-0.57f,0f);

                     Instance.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/Enfield1853_col.png");
                     foreach (var c in Instance.GetComponents<Collider2D>())
                     {
                         GameObject.Destroy(c);
                     }
                     Instance.FixColliders();
                     Instance.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/Enfield1853.png");
                     var firearm = Instance.GetComponent<FirearmBehaviour>();
                     firearm.BulletsPerShot = 1;
                     firearm.FireDelay = 0.04f;
                     firearm.InitialInaccuracy = 0.015f;
                     firearm.EjectShells = false;
                     firearm.barrelPosition = new Vector2(0.57f, 0f);
                     Cartridge customCartridge = ModAPI.FindCartridge("9mm");
                     customCartridge.name = ".557";
                     customCartridge.Damage = 20f;
                     customCartridge.Recoil = 1.8f;
                     customCartridge.ImpactForce = 1.5f;
                     customCartridge.StartSpeed = 6f;
                     firearm.Cartridge = customCartridge;
                     firearm.ShotSounds = new AudioClip[]
                     {
                           ModAPI.LoadSound("Sounds/Musket.wav"),
                     };
                     
                     var phys = Instance.GetComponent<PhysicalBehaviour>().Properties;
                     phys.Sharp = false;
                     Instance.GetComponent<PhysicalBehaviour>().TrueInitialMass = 0.35f;
                 }
             }
            );
            ModAPI.Register(
            new Modification()
             {
                 OriginalItem = ModAPI.FindSpawnable("Flintlock Pistol"),
                 NameOverride = "Martini - Henry",
                 NameToOrderByOverride = "e",
                 DescriptionOverride = "The rifle mainly used by <color=#A30E1C>24th Regiment of Foot</color>.",
                 CategoryOverride = ModAPI.FindCategory("<color=#A30E1C>Rifles</color>"),
                 ThumbnailOverride = ModAPI.LoadSprite("Icons/henry.png"),
                 AfterSpawn = (Instance) =>
                 {
                   var Weapon = Instance.transform;
                   var Cover = new GameObject("Cover");
                   Cover.transform.SetParent(Weapon);
                   Cover.transform.localPosition = new Vector3(0f, 0f);
                   Cover.transform.localRotation = Weapon.localRotation;
                   Cover.transform.localScale = new Vector3(1f, 1f);
                   Instance.GetComponent<PhysicalBehaviour>().HoldingPositions = new Vector3[]
                     {
                           new Vector3(-0.5f, 0f),
                           new Vector3(0.3f,-0f),
                     };

                     ModAPI.KeepExtraObjects();

                     (Instance.transform.Find("Hammer")).transform.localScale = new Vector3(0,0);
                     var Spark = Instance.transform.Find("Sparks");
                     Spark.transform.localPosition = new Vector3(-0.57f,0f);

                     Instance.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/Henry_col.png");
                     foreach (var c in Instance.GetComponents<Collider2D>())
                     {
                         GameObject.Destroy(c);
                     }
                     Instance.FixColliders();
                     Instance.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/Henry.png");
                     var firearm = Instance.GetComponent<FirearmBehaviour>();
                     firearm.BulletsPerShot = 1;
                     firearm.FireDelay = 0.04f;
                     firearm.InitialInaccuracy = 0.005f;
                     firearm.EjectShells = true;
                     firearm.barrelPosition = new Vector2(0.57f, 0f);
                     Cartridge customCartridge = ModAPI.FindCartridge("9mm");
                     customCartridge.name = ".402";
                     customCartridge.Damage = 20f;
                     customCartridge.Recoil = 1.8f;
                     customCartridge.ImpactForce = 1.5f;
                     customCartridge.StartSpeed = 15f;
                     firearm.Cartridge = customCartridge;
                     firearm.ShotSounds = new AudioClip[]
                     {
                           ModAPI.LoadSound("Sounds/Rifle.wav"),
                     };
                     
                     var phys = Instance.GetComponent<PhysicalBehaviour>().Properties;
                     phys.Sharp = false;
                     Instance.GetComponent<PhysicalBehaviour>().TrueInitialMass = 0.35f;
                 }
             }
            );
            ModAPI.Register(
            new Modification()
            {
                OriginalItem = ModAPI.FindSpawnable("Knife"),
                NameOverride = "<color=#A30E1C>3rd Regiment of Foot\"The Buffs\"</color> Rapier",
                NameToOrderByOverride = "a",
                DescriptionOverride = "The rapier used by officers of <color=#A30E1C>3rd Regiment of Foot\"The Buffs\"</color>, symbolizes their positions, and not sharp at all.",
                CategoryOverride = ModAPI.FindCategory("<color=#A30E1C>Rapiers</color>"),
                ThumbnailOverride = ModAPI.LoadSprite("Icons/buffs_rapier.png"),
                AfterSpawn = (Instance) =>
                {
                    Instance.transform.localScale = new Vector3(0.5f,0.5f);
                    ModAPI.KeepExtraObjects();

                    Instance.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Rapiers/Rapier_Buffs_Col.png");
                    foreach (var c in Instance.GetComponents<Collider2D>())
                    {
                        GameObject.Destroy(c);
                    }
                    Instance.FixColliders();
                    Instance.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Rapiers/Rapier_Buffs.png");

                    var phys = Instance.GetComponent<PhysicalProperties>();
                    phys.Sharp = true;
                    phys.SharpAxes = new[]
                    {
                        new SharpAxis(Vector2.up, -0.015f, 1.2f, true, false),
                    };
                    //var blade = new GameObject("blade");
                    //blade.transform.SetParent(Instance.transform);
                    //blade.transform.localPosition = new Vector3(-0.015f, 1.2f);
                    //blade.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                    //blade.transform.localScale = new Vector3(1f, 1f);
                    //var spriteblade = blade.AddComponent<SpriteRenderer>();
                    //spriteblade.sprite = ModAPI.LoadSprite("point.png");
                    //spriteblade.sortingLayerName = "Top";

                    Instance.GetComponent<PhysicalBehaviour>().HoldingPositions = new Vector3[]
                    {
                        new Vector3(-0.015f, -5f),
                    };
                }
            }
            );
            //Continental Army
            ModAPI.Register(
                new Modification()
                {
                    OriginalItem = ModAPI.FindSpawnable("Human"),
                    NameOverride = "<color=#3D6B9E>Continental Militiaman</color> Private",
                    NameToOrderByOverride = "a",
                    DescriptionOverride = "The private of <color=#3D6B9E>Continental Militiaman</color>, uses Fowler or Charleville 1766.",
                    CategoryOverride = ModAPI.FindCategory("<color=#3D6B9E>Continental Army</color>"),
                    ThumbnailOverride = ModAPI.LoadSprite("Icons/minuteman.png"),
                    AfterSpawn = (Instance) =>
                    {
                        var skin = ModAPI.LoadTexture("American/minuteman.png");
                        var flesh = ModAPI.LoadTexture("HumanFlesh.png");
                        var bone = ModAPI.LoadTexture("HumanSkeleton.png");
                        Instance.GetComponent<PersonBehaviour>().SetBodyTextures(skin, flesh, bone);

                        //cosmetics
                        var head = Instance.transform.Find("Head");
                        var childObject = new GameObject("Hat");
                        childObject.transform.SetParent(head);
                        childObject.transform.localPosition = new Vector3(0.025f, 0.15f);
                        childObject.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject.transform.localScale = new Vector3(1f, 1f);
                        var childSprite = childObject.AddComponent<SpriteRenderer>();
                        childSprite.sprite = ModAPI.LoadSprite("American/minutehat.png");
                        childSprite.sortingLayerName = "Top";

                        var shoef = Instance.transform.Find("FrontLeg").Find("FootFront");
                        var childObject3 = new GameObject("shoes");
                        childObject3.transform.SetParent(shoef);
                        childObject3.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject3.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject3.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite3 = childObject3.AddComponent<SpriteRenderer>();
                        childSprite3.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite3.sortingLayerName = "Top";

                        var shoeb = Instance.transform.Find("BackLeg").Find("Foot");
                        var childObject4 = new GameObject("shoes");
                        childObject4.transform.SetParent(shoeb);
                        childObject4.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject4.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject4.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite4 = childObject4.AddComponent<SpriteRenderer>();
                        childSprite4.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite4.sortingLayerName = "Default";

                        var tailcoat = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject5 = new GameObject("tailcoat");
                        childObject5.transform.SetParent(tailcoat);
                        childObject5.transform.localPosition = new Vector3(-0.056f, -0.05f);
                        childObject5.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject5.transform.localScale = new Vector3(1f, 1f);
                        var childSprite5 = childObject5.AddComponent<SpriteRenderer>();
                        childSprite5.sprite = ModAPI.LoadSprite("American/coat.png");
                        childSprite5.sortingLayerName = "Foreground";

                        var bag = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject6 = new GameObject("bag");
                        childObject6.transform.SetParent(bag);
                        childObject6.transform.localPosition = new Vector3(-0.05f, 0);
                        childObject6.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject6.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite6 = childObject6.AddComponent<SpriteRenderer>();
                        childSprite6.sprite = ModAPI.LoadSprite("American/bag.png");
                        childSprite6.sortingLayerName = "Foreground";

                        var sleevef = Instance.transform.Find("FrontArm").Find("LowerArmFront");
                        var childObject8 = new GameObject("sleeves");
                        childObject8.transform.SetParent(sleevef);
                        childObject8.transform.localPosition = new Vector3(0f, 0f);
                        childObject8.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject8.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite8 = childObject8.AddComponent<SpriteRenderer>();
                        childSprite8.sprite = ModAPI.LoadSprite("American/sleeves.png");
                        childSprite8.sortingLayerName = "Top";

                        var sleeveb = Instance.transform.Find("BackArm").Find("LowerArm");
                        var childObject9 = new GameObject("sleeves");
                        childObject9.transform.SetParent(sleeveb);
                        childObject9.transform.localPosition = new Vector3(0f, 0f);
                        childObject9.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject9.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite9 = childObject9.AddComponent<SpriteRenderer>();
                        childSprite9.sprite = ModAPI.LoadSprite("American/sleeves.png");
                        childSprite9.sortingLayerName = "Default";
                    }
                }
            );
            ModAPI.Register(
                new Modification()
                {
                    OriginalItem = ModAPI.FindSpawnable("Human"),
                    NameOverride = "<color=#3D6B9E>Continental Musketeer</color> Private",
                    NameToOrderByOverride = "a",
                    DescriptionOverride = "The private of <color=#3D6B9E>Continental Musketeer</color>, uses Brown Bess or Charleville 1766.",
                    CategoryOverride = ModAPI.FindCategory("<color=#3D6B9E>Continental Army</color>"),
                    ThumbnailOverride = ModAPI.LoadSprite("Icons/musketeer.png"),
                    AfterSpawn = (Instance) =>
                    {
                        var skin = ModAPI.LoadTexture("American/musketeer.png");
                        var flesh = ModAPI.LoadTexture("HumanFlesh.png");
                        var bone = ModAPI.LoadTexture("HumanSkeleton.png");
                        Instance.GetComponent<PersonBehaviour>().SetBodyTextures(skin, flesh, bone);

                        //cosmetics
                        var head = Instance.transform.Find("Head");
                        var childObject = new GameObject("Hat");
                        childObject.transform.SetParent(head);
                        childObject.transform.localPosition = new Vector3(0.025f, 0.15f);
                        childObject.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject.transform.localScale = new Vector3(1f, 1f);
                        var childSprite = childObject.AddComponent<SpriteRenderer>();
                        childSprite.sprite = ModAPI.LoadSprite("American/hat.png");
                        childSprite.sortingLayerName = "Top";

                        var sockf = Instance.transform.Find("FrontLeg").Find("LowerLegFront");
                        var childObject1 = new GameObject("socks");
                        childObject1.transform.SetParent(sockf);
                        childObject1.transform.localPosition = new Vector3(0, -0.075f);
                        childObject1.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject1.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite1 = childObject1.AddComponent<SpriteRenderer>();
                        childSprite1.sprite = ModAPI.LoadSprite("British/socks.png");
                        childSprite1.sortingLayerName = "Top";

                        var sockb = Instance.transform.Find("BackLeg").Find("LowerLeg");
                        var childObject2 = new GameObject("socks");
                        childObject2.transform.SetParent(sockb);
                        childObject2.transform.localPosition = new Vector3(0, -0.075f);
                        childObject2.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject2.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite2 = childObject2.AddComponent<SpriteRenderer>();
                        childSprite2.sprite = ModAPI.LoadSprite("British/socks.png");
                        childSprite2.sortingLayerName = "Default";

                        var shoef = Instance.transform.Find("FrontLeg").Find("FootFront");
                        var childObject3 = new GameObject("shoes");
                        childObject3.transform.SetParent(shoef);
                        childObject3.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject3.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject3.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite3 = childObject3.AddComponent<SpriteRenderer>();
                        childSprite3.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite3.sortingLayerName = "Top";

                        var shoeb = Instance.transform.Find("BackLeg").Find("Foot");
                        var childObject4 = new GameObject("shoes");
                        childObject4.transform.SetParent(shoeb);
                        childObject4.transform.localPosition = new Vector3(0, 0.0125f);
                        childObject4.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject4.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite4 = childObject4.AddComponent<SpriteRenderer>();
                        childSprite4.sprite = ModAPI.LoadSprite("British/Shoes.png");
                        childSprite4.sortingLayerName = "Default";

                        var tailcoat = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject5 = new GameObject("tailcoat");
                        childObject5.transform.SetParent(tailcoat);
                        childObject5.transform.localPosition = new Vector3(-0.056f, -0.05f);
                        childObject5.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject5.transform.localScale = new Vector3(1f, 1f);
                        var childSprite5 = childObject5.AddComponent<SpriteRenderer>();
                        childSprite5.sprite = ModAPI.LoadSprite("American/coat_mus.png");
                        childSprite5.sortingLayerName = "Foreground";

                        var bag = Instance.transform.Find("Body").Find("LowerBody");
                        var childObject6 = new GameObject("bag");
                        childObject6.transform.SetParent(bag);
                        childObject6.transform.localPosition = new Vector3(-0.05f, 0);
                        childObject6.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject6.transform.localScale = new Vector3(1.1f, 1.1f);
                        var childSprite6 = childObject6.AddComponent<SpriteRenderer>();
                        childSprite6.sprite = ModAPI.LoadSprite("American/bag.png");
                        childSprite6.sortingLayerName = "Foreground";

                        var sleevef = Instance.transform.Find("FrontArm").Find("LowerArmFront");
                        var childObject8 = new GameObject("sleeves");
                        childObject8.transform.SetParent(sleevef);
                        childObject8.transform.localPosition = new Vector3(0f, 0f);
                        childObject8.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject8.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite8 = childObject8.AddComponent<SpriteRenderer>();
                        childSprite8.sprite = ModAPI.LoadSprite("American/sleeves_mus.png");
                        childSprite8.sortingLayerName = "Top";

                        var sleeveb = Instance.transform.Find("BackArm").Find("LowerArm");
                        var childObject9 = new GameObject("sleeves");
                        childObject9.transform.SetParent(sleeveb);
                        childObject9.transform.localPosition = new Vector3(0f, 0f);
                        childObject9.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
                        childObject9.transform.localScale = new Vector3(0.6f, 0.6f);
                        var childSprite9 = childObject9.AddComponent<SpriteRenderer>();
                        childSprite9.sprite = ModAPI.LoadSprite("American/sleeves_mus.png");
                        childSprite9.sortingLayerName = "Default";
                    }
                }
            );
            ModAPI.Register(
            new Modification()
             {
                 OriginalItem = ModAPI.FindSpawnable("Flintlock Pistol"),
                 NameOverride = "Fowler",
                 NameToOrderByOverride = "f",
                 DescriptionOverride = "The rifle mainly used by <color=#3D6B9E>Continental Militiaman</color>, with copper decors.",
                 CategoryOverride = ModAPI.FindCategory("<color=#A30E1C>Rifles</color>"),
                 ThumbnailOverride = ModAPI.LoadSprite("Icons/fowler.png"),
                 AfterSpawn = (Instance) =>
                 {
                   var Weapon = Instance.transform;
                   var Cover = new GameObject("Cover");
                   Cover.transform.SetParent(Weapon);
                   Cover.transform.localPosition = new Vector3(0f, 0f);
                   Cover.transform.localRotation = Weapon.localRotation;
                   Cover.transform.localScale = new Vector3(1f, 1f);
                   Instance.GetComponent<PhysicalBehaviour>().HoldingPositions = new Vector3[]
                     {
                           new Vector3(-0.5f, 0f),
                           new Vector3(0.3f,-0f),
                     };

                     ModAPI.KeepExtraObjects();

                     var Slide = Instance.transform.Find("Hammer");
                     Slide.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/doglockmusket_hammer.png");
                     Slide.transform.localPosition = new Vector3(-0.6f, 0.05f);
                     Slide.GetComponent<SpriteRenderer>().sortingOrder = 20;

                     var Spark = Instance.transform.Find("Sparks");
                     Spark.transform.localPosition = new Vector3(-0.57f,0f);

                    Instance.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/Fowler.png");
                     foreach (var c in Instance.GetComponents<Collider2D>())
                     {
                         GameObject.Destroy(c);
                     }
                     Instance.FixColliders();
                     var firearm = Instance.GetComponent<FirearmBehaviour>();
                     firearm.BulletsPerShot = 1;
                     firearm.FireDelay = 0.04f;
                     firearm.InitialInaccuracy = 0.015f;
                     firearm.EjectShells = false;
                     firearm.barrelPosition = new Vector2(0.57f, 0f);
                     //var shotgun = Instance.GetComponent<ShotgunBehaviour>();
                     //shotgun.is_shotgun = true;
                     //shotgun.toggled_per = 12;
                     Cartridge customCartridge = ModAPI.FindCartridge("9mm");
                     customCartridge.name = "12-gauge";
                     customCartridge.Damage = 20f;
                     customCartridge.Recoil = 1.8f;
                     customCartridge.ImpactForce = 1.5f;
                     customCartridge.StartSpeed = 6f;
                     firearm.Cartridge = customCartridge;
                     firearm.ShotSounds = new AudioClip[]
                     {
                           ModAPI.LoadSound("Sounds/Musket.wav"),
                     };
                     
                     var phys = Instance.GetComponent<PhysicalBehaviour>().Properties;
                     phys.Sharp = false;
                     Instance.GetComponent<PhysicalBehaviour>().TrueInitialMass = 0.35f;
                 }
             }
            );
            ModAPI.Register(
            new Modification()
             {
                 OriginalItem = ModAPI.FindSpawnable("Flintlock Pistol"),
                 NameOverride = "Charleville 1766",
                 NameToOrderByOverride = "g",
                 DescriptionOverride = "The french rifle mainly used by <color=#3D6B9E>Continental Militiaman</color> and <color=#3D6B9E>Continental Musketeer</color>.",
                 CategoryOverride = ModAPI.FindCategory("<color=#A30E1C>Rifles</color>"),
                 ThumbnailOverride = ModAPI.LoadSprite("Icons/charleville.png"),
                 AfterSpawn = (Instance) =>
                 {
                   var Weapon = Instance.transform;
                   var Cover = new GameObject("Cover");
                   Cover.transform.SetParent(Weapon);
                   Cover.transform.localPosition = new Vector3(0f, 0f);
                   Cover.transform.localRotation = Weapon.localRotation;
                   Cover.transform.localScale = new Vector3(1f, 1f);
                   Instance.GetComponent<PhysicalBehaviour>().HoldingPositions = new Vector3[]
                     {
                           new Vector3(-0.5f, 0f),
                           new Vector3(0.3f,-0f),
                     };

                     ModAPI.KeepExtraObjects();

                     var Slide = Instance.transform.Find("Hammer");
                     Slide.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/doglockmusket_hammer.png");
                     Slide.transform.localPosition = new Vector3(-0.6f, 0.05f);
                     Slide.GetComponent<SpriteRenderer>().sortingOrder = 20;

                     var Spark = Instance.transform.Find("Sparks");
                     Spark.transform.localPosition = new Vector3(-0.57f,0f);

                    Instance.GetComponent<SpriteRenderer>().sprite = ModAPI.LoadSprite("Guns/Charleville.png");
                     foreach (var c in Instance.GetComponents<Collider2D>())
                     {
                         GameObject.Destroy(c);
                     }
                     Instance.FixColliders();
                     var firearm = Instance.GetComponent<FirearmBehaviour>();
                     firearm.BulletsPerShot = 1;
                     firearm.FireDelay = 0.04f;
                     firearm.InitialInaccuracy = 0.015f;
                     firearm.EjectShells = false;
                     firearm.barrelPosition = new Vector2(0.57f, 0f);
                     //var shotgun = Instance.GetComponent<ShotgunBehaviour>();
                     //shotgun.is_shotgun = true;
                     //shotgun.toggled_per = 12;
                     Cartridge customCartridge = ModAPI.FindCartridge("9mm");
                     customCartridge.name = ".69";
                     customCartridge.Damage = 20f;
                     customCartridge.Recoil = 1.8f;
                     customCartridge.ImpactForce = 1.5f;
                     customCartridge.StartSpeed = 6f;
                     firearm.Cartridge = customCartridge;
                     firearm.ShotSounds = new AudioClip[]
                     {
                           ModAPI.LoadSound("Sounds/Musket.wav"),
                     };
                     
                     var phys = Instance.GetComponent<PhysicalBehaviour>().Properties;
                     phys.Sharp = false;
                     Instance.GetComponent<PhysicalBehaviour>().TrueInitialMass = 0.35f;
                 }
             }
            );
        
    }
}
}